Breakout 

Derek Morey 

Description: A simple breakout clone. Run game by changing into
            the game directory and running "python3 run.py".

Controls:
            left arrow: moves paddle left
           right arrow: moves paddle right
                     p: pauses the game
                   esc: quits to main menu
